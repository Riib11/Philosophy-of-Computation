from math import *

phi  = (1 + sqrt(5))/2
phi_ = (1 - sqrt(5))/2
